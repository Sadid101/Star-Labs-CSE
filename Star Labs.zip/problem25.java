import java.util.Scanner;
public class problem25
{
  public static void main (String[] args)
  {
    Scanner scan=new Scanner(System.in);
    System.out.println("Please enter a number");
    int num=scan.nextInt();
    int space=num, count=1, back=count-1; //count is the number which will keep increasing after each row and back is for backcount
    for(int rowcount=1; rowcount<=num; rowcount++)
    {
      for(int spacecount=1; spacecount<space;spacecount++)
      {
        System.out.print(" ");
      }
      for(int numcount=1; numcount<=count;  numcount++)
      {
        System.out.print(numcount);
      }
      for(int backcount=back; backcount>=1; backcount--)
      {
        System.out.print(backcount);
      }
      System.out.println();
      back++;
      count++;
      space--;
    }
  }
}
        
       
    