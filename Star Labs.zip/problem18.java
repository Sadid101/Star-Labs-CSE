import java.util.Scanner;
public class problem18
{
  public static void main(String[] args)
  {
    Scanner  scan=new Scanner(System.in);
    System.out.println("Please enter a number");
    int rows=scan.nextInt(); 
    int space=rows, stargap=0; //for gaps in between stars
    for (int rowcount=1; rowcount<rows; rowcount++) //all lines but last
    {
      for (int spacecount=1; spacecount<=space; spacecount++)
      {
        if(spacecount==space)
        {
          System.out.print("*");
        }
        else
        {
          System.out.print(" ");
        }
      }
      for(int gap=1; gap<=stargap; gap++)
      {
        if (gap==stargap)
        {
          System.out.print("*");
        }
        else
        {
          System.out.print(" ");
        }
      }
      System.out.println();
      space--;
      stargap++;
    }
    for (int starcount=1; starcount<=rows; starcount++)
    {
      System.out.print("*");
    }
  }
}