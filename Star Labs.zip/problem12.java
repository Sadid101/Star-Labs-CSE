import java.util.Scanner;
public class problem12
{
  public static void main (String[] args)
  {
    Scanner scan=new Scanner(System.in);
    System.out.println("Please enter a number");
    int a=scan.nextInt();
    int star=1, space=a;
    for(int rcount=1; rcount<=a; rcount++) //rcount being less than a leaves one letter gap for star to fit in 
    {
      for(int spacecount=1; spacecount<space; spacecount++)
      {
        System.out.print(" ");
      }
      for(int starcount=1; starcount<=star; starcount++)
      {
        System.out.print("*");
      }
      System.out.println();
      space--; 
      star+=2; //as 2 stars are being added each line
    }
    space=1;
    star-=2; //as at the end of the for loop we end up with 2 extra stars from line 22
    for(int backcount=1; backcount<a; backcount++) //backcount is the repeated star below
    {
      star-=2; //as 2 stars are being removed each line
      for(int spacecount=1; spacecount<=space; spacecount++)
      {
        System.out.print(" ");
      }
      for(int starcount=1; starcount<=star; starcount++)
      {
        System.out.print("*");
      }
      System.out.println();
      space++; 
    }
  }
}