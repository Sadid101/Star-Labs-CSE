import java.util.Scanner;
public class problem5
{
  public static void main (String[] args)
  {
    Scanner scan=new Scanner(System.in);
    System.out.println("Please enter a number"); 
    int stars=scan.nextInt();
    int b=1;
    for(int rcount=1; rcount<=stars; rcount++)
    {
    for (int starcount=1; starcount<=b; starcount++)
    {
      System.out.print("*");
    }
    System.out.println();
    b++;
    }
  }
}