import java.util.Scanner;
public class problem23
{
  public static void main(String[] args)
  {
    Scanner  scan=new Scanner(System.in);
    System.out.println("Please enter a number");
    int rows=scan.nextInt();
    int upperrows=0; //counts the number of upper rows before it starts decreasing
    int space=rows, numgap=1;//for gaps in between stars
    for (int rowcount=1; rowcount<=rows; rowcount++) //all lines before repeatation
    {
      for (int spacecount=1; spacecount<=space; spacecount++)
      {
        if(spacecount==space)
        {
          System.out.print(1);
        }
        else
        {
          System.out.print(" ");
        }
      }
      for(int gap=2; gap<=numgap; gap++) //gap=2 so that it doesnt give a gap in the first row
      {
        if (gap==numgap)
        {
          System.out.print(gap);
        }
        else
        {
          System.out.print(" ");
        }
      }
      System.out.println();
      space--;
      numgap+=2;
      upperrows++;
    }
    numgap-=4;
    space+=2; //one space is reduced already in line 35 and to add extra space
    for(int rowcount2=1; rowcount2<=upperrows-1; rowcount2++)
    {
      for (int spacecount=1; spacecount<=space; spacecount++) //lower part of the rhombus starts here
      {
        if(spacecount==space)
        {
          System.out.print(1);
        }
        else
        {
          System.out.print(" ");
        }
      }
      for(int gap=2; gap<=numgap; gap++) //gap=2 so that it doesnt give a gap in the first row
      {
        if (gap==numgap)
        {
          System.out.print(gap);
        }
        else
        {
          System.out.print(" ");
        }
      }
      System.out.println();
      space++;
      numgap-=2;
    }
  }
}




