import java.util.Scanner;
public class problem6
{
  public static void main (String[] args)
  {
    Scanner scan=new Scanner(System.in);
    System.out.println("Please enter a number"); 
    int rows=scan.nextInt();
    int b=1;
    for(int rcount=1; rcount<=rows; rcount++)
    {
    for (int numcount=1; numcount<=b; numcount++)
    {
      System.out.print(numcount);
    }
    System.out.println();
    b++;
    }
  }
}