import java.util.Scanner;
public class problem24
{
  public static void main(String[] args)
  {
    Scanner scan=new Scanner(System.in);
    System.out.println("Please enter a number");
    int num=scan.nextInt();
    for(int numcount=1; numcount<=num; numcount++)
    {
      System.out.print(numcount);
    }
    num--;
    for(int backcount=num; backcount>=1; backcount--)
    {
      System.out.print(backcount);
    }
  }
}