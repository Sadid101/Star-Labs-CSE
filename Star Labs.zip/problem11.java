import java.util.Scanner;
public class problem11
{
  public static void main (String[] args)
  {
    Scanner scan=new Scanner(System.in);
    System.out.println("Please enter a number");
    int a=scan.nextInt();
    int num=1, space=a;
    for(int rcount=1; rcount<=a; rcount++) //rcount being less than a leaves one letter gap for num to fit in 
    {
      for(int spacecount=1; spacecount<space; spacecount++)
      {
        System.out.print(" ");
      }
      for(int numcount=space; numcount<=a; numcount++)
      {
        System.out.print(numcount);
      }
      System.out.println();
      space--; 
      num++;
    }
  }
}
