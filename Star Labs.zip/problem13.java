import java.util.Scanner;
public class problem13
{
  public static void main (String[] args)
  {
    Scanner scan=new Scanner(System.in);
    System.out.println("Please enter a number");
    int a=scan.nextInt();
    int num=1, space=a;
    for(int rcount=1; rcount<=a; rcount++) //rcount being less than a leaves one letter gap for num to fit in 
    {
      for(int spacecount=1; spacecount<space; spacecount++)
      {
        System.out.print(" ");
      }
      for(int numcount=1; numcount<=num; numcount++)
      {
        System.out.print(numcount);
      }
      System.out.println();
      space--; 
      num+=2; //as 2 nums are being added each line
    }
    space=1;
    num-=2; //as at the end of the for loop we end up with 2 extra nums from line 22
    for(int backcount=1; backcount<a; backcount++) //backcount is the repeated num below
    {
      num-=2; //as 2 nums are being removed each line
      for(int spacecount=1; spacecount<=space; spacecount++)
      {
        System.out.print(" ");
      }
      for(int numcount=1; numcount<=num; numcount++)
      {
        System.out.print(numcount);
      }
      System.out.println();
      space++; 
    }
  }
}