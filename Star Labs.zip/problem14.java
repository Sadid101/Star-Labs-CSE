import java.util.Scanner;
public class problem14
{
  public static void main(String[] args)
  {
    Scanner scan=new Scanner(System.in);
    System.out.println("Pease enter length");
    int l=scan.nextInt();
    System.out.println("Pease enter width");
    int w=scan.nextInt();
    for(int starcount=1; starcount<=w; starcount++)
    {
      System.out.print("*");
    }
    System.out.println();
    for(int row=2; row<l; row++)
    {
      System.out.print("*");
      for(int space=1; space<=w-2; space++) //w-2 as one star at beginning and one at the end
      {
        System.out.print(" ");
      }
      System.out.println("*");
    }
    for(int starcount=1; starcount<=w; starcount++)
    {
      System.out.print("*");
    }
  }
}
