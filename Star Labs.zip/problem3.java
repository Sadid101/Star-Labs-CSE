import java.util.Scanner;
public class problem3
{
  public static  void main(String[] args)
  {
    Scanner scan=new Scanner(System.in);
    System.out.println("Please enter a number of rows");
    int row= scan.nextInt();
    System.out.println("Please enter a number of columns");
    int columns= scan.nextInt();
    for (int ccount=1; ccount<=columns; ccount++)
    {
      System.out.print("*"); //rrow
    }
    for (int rcount=2; rcount<=row; rcount++) //rcount starts at 2 since one row is already printed and marked as rrow
    { 
      System.out.println("");
      for (int ccount=1; ccount<=columns; ccount++)
      {
        System.out.print("*");
      }
    }
  }
}