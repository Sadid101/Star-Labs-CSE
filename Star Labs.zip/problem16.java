import java.util.Scanner;
public class problem16
{
  public static void main(String[] args)
  {
    Scanner scan=new Scanner(System.in);
    System.out.println("Please enter length");
    int l=scan.nextInt();
    int space=0;
    for(int rowcount=1; rowcount<l; rowcount++) 
    {
      System.out.print("*"); //first star
      for(int spacecount=1; spacecount<=space; spacecount++) //all lines in between 1st and last
      {
        if(spacecount==space)
        {
          System.out.print("*");
        }
        else
        {
          System.out.print(" ");
        }
      }
      System.out.println();
      space++;
    }
    for(int starcount=1; starcount<=space+1; starcount++) //space+1 since the initial star which was being printed is no longer there at line 12
    {
      System.out.print("*");
    }
  }
}
