import java.util.Scanner;
public class problem17
{
  public static void main(String[] args)
  {
    Scanner scan=new Scanner(System.in);
    System.out.println("Please enter length");
    int l=scan.nextInt();
    int space=1;
    for(int rowcount=1; rowcount<l; rowcount++) 
    {
      System.out.print(1); //first star
      for(int spacecount=2; spacecount<=space; spacecount++) //all lines in between 1st and last //it starts at 2 since 1 is already done
      {
        if(spacecount==space)
        {
          System.out.print(spacecount);
        }
        else
        {
          System.out.print(" ");
        }
      }
      System.out.println();
      space++;
    }
    for(int numcount=1; numcount<=space; numcount++)
    {
      System.out.print(numcount);
    }
  }
}
