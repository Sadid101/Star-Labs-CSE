import java.util.Scanner;
public class problem20
{
  public static void main(String[] args)
  {
    Scanner  scan=new Scanner(System.in);
    System.out.println("Please enter a number");
    int rows=scan.nextInt(); 
    int space=rows, stargap=1; //for gaps in between stars
    for (int rowcount=1; rowcount<rows; rowcount++) //all lines but last
    {
      for (int spacecount=1; spacecount<=space; spacecount++)
      {
        if(spacecount==space)
        {
          System.out.print("*");
        }
        else
        {
          System.out.print(" ");
        }
      }
      for(int gap=2; gap<=stargap; gap++) //gap=2 so that it doesnt give a gap in the first row
      {
        if (gap==stargap)
        {
          System.out.print("*");
        }
        else
        {
          System.out.print(" ");
        }
      }
      System.out.println();
      space--;
      stargap+=2;
    }
    for (int starcount=1; starcount<=(rows*2-1); starcount++)
    {
      System.out.print("*");
    }
  }
}