import java.util.Scanner;
public class problem21
{
  public static void main(String[] args)
  {
    Scanner  scan=new Scanner(System.in);
    System.out.println("Please enter a number");
    int rows=scan.nextInt(); 
    int space=rows, numgap=1; //for gaps in between nums
    for (int rowcount=1; rowcount<rows; rowcount++) //all lines but last
    {
      for (int spacecount=1; spacecount<=space; spacecount++)
      {
        if(spacecount==space)
        {
          System.out.print(1);
        }
        else
        {
          System.out.print(" ");
        }
      }
      for(int gap=2; gap<=numgap; gap++) //gap=2 so that it doesnt give a gap in the first row
      {
        if (gap==numgap)
        {
          System.out.print(gap);
        }
        else
        {
          System.out.print(" ");
        }
      }
      System.out.println();
      space--;
      numgap+=2;
    }
    for (int numcount=1; numcount<=(rows*2-1); numcount++)
    {
      System.out.print(numcount);
    }
  }
}