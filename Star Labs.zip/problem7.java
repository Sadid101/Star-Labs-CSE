import java.util.Scanner;
public class problem7
{
  public static void main (String[] args)
  {
    Scanner scan=new Scanner(System.in);
    System.out.println("Please enter a number");
    int a=scan.nextInt();
    int star=1, space=a;
    for(int rcount=1; rcount<=a; rcount++) //rcount being less than a leaves one letter gap for star to fit in 
    {
      for(int spacecount=1; spacecount<space; spacecount++)
      {
        System.out.print(" ");
      }
      for(int starcount=1; starcount<=star; starcount++)
      {
        System.out.print("*");
      }
      System.out.println();
      space--; 
      star++;
    }
  }
}
