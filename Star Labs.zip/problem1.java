import java.util.Scanner;
public class problem1
{
  public static  void main(String[] args)
  {
    Scanner scan=new Scanner(System.in);
    System.out.println("Please enter a number");
    int a= scan.nextInt();
    for (int count=1; count<=a; count++)
    { 
      System.out.print(count);
    }
  }
}